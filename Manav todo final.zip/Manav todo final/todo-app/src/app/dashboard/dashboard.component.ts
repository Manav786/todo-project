import { Component, OnInit } from '@angular/core';
import { todo } from '../app.component';
import { ActivatedRoute, Router } from '@angular/router';
import { TodoService } from '../todo.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  todos: any = [];
  mode = 0; // add
  constructor(private route: Router, private todoService: TodoService) {
    this.fetchTodos();
  }

  ngOnInit(): void {}
  fetchTodos(){
    this.todoService.getTodos().subscribe((data) => {
      this.todos = data;
      console.log(this.todos);
    });
  }
  edit(item: todo) {
    let conf = confirm('Are you sure want to update this task?');
    if (conf == true) {
    const id = this.todos.findIndex((i:todo) => i._id == item._id);
    console.log(id);
    this.route.navigateByUrl('/addTodo?id=' + item._id);

  }
  }
  delete(item: todo) {
    let conf = confirm('Are you sure want to delete this task?');
    if (conf == true) {
      const todoToDelete = this.todos.find((i:todo) => i._id == item._id);
      console.log(todoToDelete);
      
      this.todoService.deleteTodos(todoToDelete._id).subscribe(
        (data) => {
          // console.log(data);
          this.fetchTodos();
          setTimeout(() => {
            alert('Task Deleted Successfully');
          }, 400);
          
        },
        (err) => {
          console.log(err);
        }
      );

    //   setTimeout(() => {
    //     alert('Task is deleted successfully');
    //   }, 200);
   }
  }
  // deleteData(item:todo){
  //   var conf=confirm('Are you sure want to delete this task?')
  //   if (conf == true) {
  //     let itemlocal:any=localStorage.getItem("itemJson");
  //     this.todos=JSON.parse(itemlocal);

  //     this.todos.splice(id,1);
  //     localStorage.setItem("itemJson",JSON.stringify(this.todos));
  //     alert("Task is deleted successfully");

  //   console.log("deleting data!");

  //   }
  //   }
 
}
