import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { todo } from './app.component';
@Injectable({
  providedIn: 'root'
})
export class TodoService {
  api_url="http://localhost:3200/users/"
  constructor(private http:HttpClient) { }
  getTodos(){
    return this.http.get<todo[]>(this.api_url);
  }
  getTodosById(id:string){
    return this.http.get(this.api_url+id);
  }
  setTodos(todo:todo){
    return this.http.post(this.api_url,todo);
  }
  editTodos(todo:any){
    
    console.log(todo);
    const entries = Object.entries(todo);
    console.log(todo.status);
    // console.log(todo.id);
    const url =this.api_url+todo.id;
    console.log(url);
    
    return this.http.put(url,todo);
  }
  deleteTodos(todoid:string){
    console.log('Record deleted of id'+todoid);
    console.log(this.api_url+todoid);
    return this.http.delete(this.api_url+todoid);
  }
}
