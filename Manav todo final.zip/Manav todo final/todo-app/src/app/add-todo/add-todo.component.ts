import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm, Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TodoService } from '../todo.service';
import { todo } from '../app.component';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-todo',
  templateUrl: './add-todo.component.html',
  styleUrls: ['./add-todo.component.css'],
})
export class AddTodoComponent implements OnInit {
  title = 'todo-app';
  todos: todo[] = [];
  mode = false; // add
  _id: string = '';
  submitted = false;
  checkoutForm: any;
  mindate: any = '';

  constructor(
    private _router: Router,
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private todoService: TodoService
  ) {}
  ngOnInit(): void {
    this.checkoutForm = this.formBuilder.group({
      id: [''],
      title: ['', Validators.required],
      description: ['', Validators.required],
      lastdate: [this.getDate(), Validators.required],
      status: ['', Validators.required],
    });
    this.getDate();

    this.activatedRoute.queryParams.subscribe((params) => {
      const todoData: any = params;
      if (params['id'] == '') {
        console.log('value null');
        this._router.navigateByUrl('/');
      }
      else if (params['id']) {
        console.log(params['id']);
        this._id = params['id'];
        this.mode = true; //edit
        // const todo = this.todos[params['id']];
        this.todoService.getTodosById(this._id).subscribe(
          (data) => {
            console.log(data);
            const todoData: any = data;
            console.log(todoData._id);

            this.checkoutForm.controls['id'].setValue(todoData._id);
            this.checkoutForm.controls['title'].setValue(todoData.title);
            this.checkoutForm.controls['description'].setValue(
              todoData.description
            );

            this.checkoutForm.controls['lastdate'].setValue(todoData.lastdate);
            this.checkoutForm.controls['status'].setValue(todoData.status);
          },
          (err) => {
            console.log(err);
          }
        );
      }
    });
  }

  get formControl() {
    return this.checkoutForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    console.log(this.checkoutForm);
    if (this.checkoutForm.valid) {
      if (!this.mode) {
        // console.log(this.checkoutForm.value);
        // this.todos.push(this.checkoutForm.value);

        this.todoService.setTodos(this.checkoutForm.value).subscribe(
          (data) => {
            console.log(data);
            setTimeout(() => {
              alert('Task Added Successfully');
            }, 400);
          },
          (err) => {
            console.log(err);
          }
        );
      } else {
        // this.todos[this.id] = this.checkoutForm.value;
        this.todoService.editTodos(this.checkoutForm.value).subscribe(
          (data) => {
            console.log(data);
            setTimeout(() => {
              alert('Task Updated Successfully');
            }, 400);
          },
          (err) => {
            console.log(err);
          }
        );
      }

      this._router.navigateByUrl('/');
    }
  }
  getDate() {
    var date = new Date();
    var tdate: any = date.getDate();
    if (tdate < 10) {
      tdate = '0' + tdate;
    }
    var month: any = date.getMonth() + 1;
    if (month < 10) {
      month = '0' + month;
    }
    var year = date.getUTCFullYear();

    this.mindate = year + '-' + month + '-' + tdate;
    console.log(this.mindate);
    return this.mindate;
  }
}
